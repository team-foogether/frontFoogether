type LoginNaviParamList = {
    Login: undefined;
    Signup: undefined;
    PasswordReset: undefined;
  };
  
  type MyFeedTabParamList = {
    MyFeed: undefined;
  };
  
  type FeedsTabParamList = {
    Feeds: undefined;
    FeedListOnly: undefined;
  };
  
  type ProfileTabParamList = {
    Profile: undefined;
  };